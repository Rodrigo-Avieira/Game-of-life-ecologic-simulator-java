package CapstoneRodrigoAraujoVieira.Mapa;

import java.util.Random;

public class Parametros {
    public int largura;
    public int altura;
    public int geracoes;
    public int intervaloMs;
    public int direcao = 1;
    public int [][] mapaInicial;
    public String mapaStr;

    public boolean valido = true;//valor de controle
    public String erro = "";//deixar setado a string pra manipular erro

    public Parametros(String[] args){
        for (String arg : args){
            if (!arg.contains("=")) continue;

            String [] dividindoParametro = arg.split("=");
            if (dividindoParametro.length != 2) continue;

            String chave = dividindoParametro[0];
            String valor = dividindoParametro[1];

            try{//try/catch para possiveis erros na passagem dos parãmetros
                switch (chave){
                    case "w":
                        largura = Integer.parseInt(valor);
                        break;
                    case "h":
                        altura = Integer.parseInt(valor);
                        break;
                    case "g":
                        geracoes = Integer.parseInt(valor);
                        break;
                    case "s":
                        intervaloMs = Integer.parseInt(valor);
                        break;
                    case "n":
                        direcao = Integer.parseInt(valor);
                        if (direcao < 1 || direcao > 4) {
                            throw new IllegalArgumentException("Direção inválida (1-4)");
                        }
                            break;
                    case "m":
                        mapaStr = valor;
                        break;
                    default:
                        valido = false;
                        erro = "Parâmetro desconhecido: %s".formatted(chave);
                }

            }catch (Exception e){//tratamento de erros mais generico
                valido = false;
                erro = "Falha ao ler argumento: " + chave + " - " + e.getMessage();
            }
        }

        //validando se os parametros estao dentro do esperado
        if (largura <= 0 || altura <=0 || intervaloMs < 0 || mapaStr == null){
            valido = false;
            if (erro.isEmpty()) erro = "Parâmetros Obrigatórios inválidos";
            return;
        }

        //Processando o mapa
        if (mapaStr.equalsIgnoreCase("rnd")){
            mapaInicial = gerarMapaAleatorio();
        }else{
            mapaInicial = interpretarMapaManual(mapaStr);
            if (mapaInicial == null){
                valido = false;
                if(erro.isEmpty()) erro = "Erro ao interpretar mapa" ;
            }
        }

    }
    private int [][] interpretarMapaManual(String texto) {
        String[] linhas = texto.split("#");
        int[][] mapa = new int[largura][largura];

        for (int i = 0; i < altura; i++) {
            if (i >= linhas.length) break;
            String linha = linhas[i];

            for (int j = 0; j < largura; j++) {
                if (j >= linhas.length) continue;

                char c = linha.charAt(j);
                if (c < '0' || c > '3') continue;

                mapa[i][j] = Character.getNumericValue(c);
            }
        }
        return mapa;
    }

    private int [][] gerarMapaAleatorio(){
        int [][] mapa = new int[altura][largura];
        Random random = new Random();

        for (int i = 0; i < altura; i++){
            for (int j = 0; j < largura; j++){
                mapa [i][j] = random.nextInt(4);//jogando os numeros entre 0 e 3
            }
        }
        return mapa;
    }

    public void exibirParametros(){//método pra puxar as info e printar na main
        System.out.println("----- Parâmetros do GOL -----");
        System.out.println("Largura: " + largura);
        System.out.println("Altura: " + altura);
        System.out.println("Gerações: " + (geracoes == 0 ? "Infinitas" : geracoes));
        System.out.println("Intervalo: " + intervaloMs + "ms");
        System.out.println("Direção de movimento: " + direcao);
        System.out.println("Mapa Inicial");
        String [] grafico = {"\uD83D\uDFEB", "\uD83C\uDF33", "\uD83E\uDDAC", "\uD83C\uDF0A"};
        for (int [] linha : mapaInicial){
            for (int valor : linha){
                System.out.print("\t" + grafico[valor]);
            }
            System.out.println();
        }
    }
}

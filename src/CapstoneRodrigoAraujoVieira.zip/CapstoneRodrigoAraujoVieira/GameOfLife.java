package CapstoneRodrigoAraujoVieira;

import CapstoneRodrigoAraujoVieira.Mapa.Parametros;

//w=15 h=15 g=10 s=500 m=rnd n=2
public class GameOfLife {

    public static void main(String[] args) {
        Parametros p = new Parametros(args);

        if (!p.valido) {
            System.out.println("Erro: " + p.erro);
            return;
        }
        //Parametros p1 = p;
        p.exibirParametros();
    }
}
